from discord.ext import commands
from .utils import checks
import json
import discord

class Autorole:
    """Autorole"""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(pass_context = True)
    @checks.is_owner()
    async def autorole(self, ctx, role: str = None):
        """Sets a role to be assigned automatically to new server members."""
        server = ctx.message.server
        if role is None:
            with open('autorole.json', 'w') as configFile:
                self.roleAuto = {server.id: 0}
                json.dump(self.roleAuto, configFile)
            await self.bot.say("Autorole reset.")
            return
        try:
            self.roleId = int(role)
        except ValueError:
            self.aRole = discord.utils.get(server.roles, name=role)
            try:
                self.roleId = self.aRole.id
            except AttributeError:
                await self.bot.say("Role does not exist.")
                return
        with open('autorole.json', 'w') as configFile:
            self.roleAuto = {server.id: self.roleId}
            json.dump(self.roleAuto, configFile)
        await self.bot.say("Autorole set to '" + role + "'")

    async def on_member_join(self, member):
        with open('autorole.json', 'r') as configFile:
            self.config = json.load(configFile)
            try:
                self.roleId = self.config[member.server.id]
                if self.roleId == 0:
                    return
                self.roleAuto = discord.utils.get(member.server.roles, id=self.roleId)
                await self.bot.add_roles(member, self.roleAuto)
            except KeyError:
                pass

def setup(bot):
    bot.add_cog(Autorole(bot))
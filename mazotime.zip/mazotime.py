from discord.ext import commands
import discord
from pytz import timezone
from .utils import checks
from datetime import datetime

class MazoTimeCog:
    """Display time in CEST"""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(pass_context = True)
    async def mazotime(self):
        """Returns the current time in Belgium"""
        cest = timezone('Europe/Berlin')
        de_time = datetime.now(cest)
        de_time_24hour = datetime.strptime(de_time.strtime('%H:%M'), '%H:%M')
        await self.bot.say(de_time_24hour.strftime("%I:%M %p"))

def setup(bot):
    bot.add_cog(MazoTimeCog(bot))